Progetto Principi e Modelli della Percezione, Eumir Cometti 986666 Università degli Studi di Milano

OF_Farenback.py: codice python per il calcolo dell'optical flow con l'algoritmo di Farenback

Lucas-Kanade.py: codice python per il calcolo dell'optical flow con l'algoritmo di Lucas-Kanade

Optical Flow e percezione umana del movimento.pdf: presentazione powerpoint del progetto

Progetto Principi e Modelli della Percezione - Eumir Cometti.pdf: progetto completo

traffico.avi / traffico.flv: file per il calcolo dell'optical flow
